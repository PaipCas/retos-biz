import '@testing-library/jest-dom';
import { render } from '@testing-library/react';
import Container from '../components/container/Container';

test('renders content', () => {
	const component = render(<Container />);
	console.log(component);
});